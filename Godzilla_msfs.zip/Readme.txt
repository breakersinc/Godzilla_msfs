Imagine yourself flying in the storm with poor visibility and suddenly discover the lightning silhouette of the King of the Monsters.
Stop imagining it. Now you can feel it.

  ▄████  ▒█████  ▓█████▄ ▒███████▒ ██▓ ██▓     ██▓    ▄▄▄       
 ██▒ ▀█▒▒██▒  ██▒▒██▀ ██▌▒ ▒ ▒ ▄▀░▓██▒▓██▒    ▓██▒   ▒████▄     
▒██░▄▄▄░▒██░  ██▒░██   █▌░ ▒ ▄▀▒░ ▒██▒▒██░    ▒██░   ▒██  ▀█▄   
░▓█  ██▓▒██   ██░░▓█▄   ▌  ▄▀▒   ░░██░▒██░    ▒██░   ░██▄▄▄▄██  
░▒▓███▀▒░ ████▓▒░░▒████▓ ▒███████▒░██░░██████▒░██████▒▓█   ▓██▒ 
 ░▒   ▒ ░ ▒░▒░▒░  ▒▒▓  ▒ ░▒▒ ▓░▒░▒░▓  ░ ▒░▓  ░░ ▒░▓  ░▒▒   ▓▒█░ 
  ░   ░   ░ ▒ ▒░  ░ ▒  ▒ ░░▒ ▒ ░ ▒ ▒ ░░ ░ ▒  ░░ ░ ▒  ░ ▒   ▒▒ ░ 
░ ░   ░ ░ ░ ░ ▒   ░ ░  ░ ░ ░ ░ ░ ░ ▒ ░  ░ ░     ░ ░    ░   ▒    
      ░     ░ ░     ░      ░ ░     ░      ░  ░    ░  ░     ░  ░ 
                  ░      ░                                      
  █████▒▒█████   ██▀███      ███▄ ▄███▓  ██████   █████▒ ██████ 
▓██   ▒▒██▒  ██▒▓██ ▒ ██▒   ▓██▒▀█▀ ██▒▒██    ▒ ▓██   ▒▒██    ▒ 
▒████ ░▒██░  ██▒▓██ ░▄█ ▒   ▓██    ▓██░░ ▓██▄   ▒████ ░░ ▓██▄   
░▓█▒  ░▒██   ██░▒██▀▀█▄     ▒██    ▒██   ▒   ██▒░▓█▒  ░  ▒   ██▒
░▒█░   ░ ████▓▒░░██▓ ▒██▒   ▒██▒   ░██▒▒██████▒▒░▒█░   ▒██████▒▒
 ▒ ░   ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░   ░ ▒░   ░  ░▒ ▒▓▒ ▒ ░ ▒ ░   ▒ ▒▓▒ ▒ ░
 ░       ░ ▒ ▒░   ░▒ ░ ▒░   ░  ░      ░░ ░▒  ░ ░ ░     ░ ░▒  ░ ░
 ░ ░   ░ ░ ░ ▒    ░░   ░    ░      ░   ░  ░  ░   ░ ░   ░  ░  ░  
           ░ ░     ░               ░         ░               ░  
 
Not located in Tokyo because TOKIO IS NOT PHOTOGRAMMETRY MESHED in FS2020. :((

My 1st try of Fictional scenery.

If ANYONE likes it, I Will do KING KONG up the Empire State.
Or the Burj Khalifa?

Install: By copying \godzilla to your FS2020 Content "Community" folder.
Location: 37.792394, -122.378850
Author: Sergio Perea <muyprofesional@gmail.com>


License: CC BY-NC 4.0 (due to the Moai model used; see below)
Model attribution: https://sketchfab.com/Laserdesign
Model: https://sketchfab.com/3d-models/godzilla-2019-figurine-3d-scan-d2f8c8616297405d8a8026e5dbfbbe45

